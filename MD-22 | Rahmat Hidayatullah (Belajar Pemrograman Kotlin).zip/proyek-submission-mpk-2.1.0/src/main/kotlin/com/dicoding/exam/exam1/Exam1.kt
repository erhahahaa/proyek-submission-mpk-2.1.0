package com.dicoding.exam.exam1

fun isEvenNumber(number: Int): Boolean = number % 2 == 0

fun moreThanFive(number: Int): Boolean = number > 5

fun result(number: Int): Int = number * (number + 10)
