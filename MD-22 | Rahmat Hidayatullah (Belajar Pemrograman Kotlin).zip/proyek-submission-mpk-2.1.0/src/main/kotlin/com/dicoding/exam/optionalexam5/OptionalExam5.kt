package com.dicoding.exam.optionalexam5

val concatString: (String, String) -> String = String::plus
